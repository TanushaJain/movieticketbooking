import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ticketbooking',
  templateUrl: './ticketbooking.component.html',
  styleUrls: ['./ticketbooking.component.css']
})
export class TicketbookingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
